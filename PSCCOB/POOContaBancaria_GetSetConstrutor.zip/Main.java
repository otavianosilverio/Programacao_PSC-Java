class Main {
  public static void main(String[] args) {
    double saldototal;
    System.out.println("Criar um classe do cliente Renan");
    //
    ContaBancaria PF0901 = new ContaBancaria(10909,1025);
    
    //PF0901.numero = 10909;
   // PF0901.agencia = 1025;
    
    PF0901.depositar(1000);
    PF0901.SetNumero(10910);
    System.out.println("Numero da Conta + Agencia -> "+PF0901.GetNumero()+" - "+PF0901.getAgencia());
    System.out.println("Saldo da conta PF0901 "+PF0901.ConsultarSaldo());
  }  
}